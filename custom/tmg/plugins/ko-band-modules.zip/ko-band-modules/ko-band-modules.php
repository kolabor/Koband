<?php 
/*
Plugin Name: Koband Modules
Plugin URI: http://www.kolabor.net/
Description: Special custom plugin for Koband theme
Author: Kolabor.net
Author URI: http://www.kolabor.net/
Text Domain: koband
Domain Path: /languages/
Version: 1.0.0
*/

register_activation_hook(__FILE__, 'ko_band_module_install');
function ko_band_module_install()
{
	global $wp_version;

	if (version_compare($wp_version, '4.6', '<'))
	{
		wp_die('This plugin works better with Wordpress versions older than 4.5');
	}
}

/* Include CPT & Taxonomy files */
include( plugin_dir_path( __FILE__ ) . 'include/ko_band_albums_custom_post_type.php');
include( plugin_dir_path( __FILE__ ) . 'include/ko_band_media_custom_post_type.php'); 
include( plugin_dir_path( __FILE__ ) . 'include/ko_band_singles_custom_post_types.php'); 
include( plugin_dir_path( __FILE__ ) . 'include/ko_band_slides_custom_post_types.php');
include( plugin_dir_path( __FILE__ ) . 'include/ko_band_the_band_custom_post_type.php'); 
include( plugin_dir_path( __FILE__ ) . 'include/ko_band_tour_custom_post_type.php');  

/* Register koband resources (js & css) */
function ko_band_custom_wp_admin_plugin_resources() {

    wp_register_style( 'koband_wp_admin_css', get_template_directory_uri() . '/admin/ko_band_admin.css', false, '1.0.0' );
    wp_enqueue_style( 'koband_wp_admin_css' );

    wp_register_script( 'koband_wp_admin_js', get_template_directory_uri() . '/admin/ko_band_admin_min.js', false, '1.0.0' );
    wp_enqueue_script( 'koband_wp_admin_js' );

    wp_register_style( 'bootstrap_grid', get_template_directory_uri() . '/admin/bootstrap-grid.min.css', false, '1.0.0' );
    wp_enqueue_style( 'bootstrap_grid' );

    wp_register_style( 'bootstrap', get_template_directory_uri() . '/admin/bootstrap.min.css', false, '1.0.0' );
    wp_enqueue_style( 'bootstrap' );
    
    add_editor_style( 'css/custom-editor-style.css' );
}
add_action( 'admin_enqueue_scripts', 'ko_band_custom_wp_admin_plugin_resources' );

/* Change featured image name */
function ko_band_featured_image_metabox_title() {

	remove_meta_box( 'postimagediv', 'album', 'side' );
	add_meta_box( 'postimagediv', esc_html__( 'Set cover image', 'koband' ), 'post_thumbnail_meta_box', 'album', 'side' );

	remove_meta_box( 'postimagediv', 'media', 'side' );
	add_meta_box( 'postimagediv', esc_html__( 'Set gallery cover', 'koband' ), 'post_thumbnail_meta_box', 'media', 'side' );

	remove_meta_box( 'postimagediv', 'singles', 'side' );
	add_meta_box( 'postimagediv', esc_html__( 'Set cover image', 'koband' ), 'post_thumbnail_meta_box', 'singles', 'side' );

	remove_meta_box( 'postimagediv', 'slides', 'side' );
	add_meta_box( 'postimagediv', esc_html__( 'Set slide images', 'koband' ), 'post_thumbnail_meta_box', 'slides', 'side' );

	remove_meta_box( 'postimagediv', 'the band', 'side' );
	add_meta_box( 'postimagediv', esc_html__( 'Band Member image', 'koband' ), 'post_thumbnail_meta_box', 'the band', 'side' );

}
add_action('do_meta_boxes', 'ko_band_featured_image_metabox_title' );


// Search for posts and CPT
add_filter( 'pre_get_posts', 'ko_band_cpt_search' );
/**
 * This function modifies the main WordPress query to include an array of 
 * post types instead of the default 'post' post type.
 *
 * @param object $query  The original query.
 * @return object $query The amended query.
 */
function ko_band_cpt_search( $query ) {
	
    if ( $query->is_search ) {
	$query->set( 'post_type', array( 'post', 'media', 'album', 'tour', 'singles', 'theband' ) );
    $query->query_vars['posts_per_page'] = -1;
    }
    
    return $query;
    
}


?>